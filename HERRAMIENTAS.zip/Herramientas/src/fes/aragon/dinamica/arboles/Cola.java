package fes.aragon.dinamica.arboles;

public class Cola<E> {
    private NodoCola<E> frente;
    private NodoCola<E> fin;
    private int tamaño;

    // Clase interna para los nodos de la cola
    private class NodoCola<T> {
        T dato;
        NodoCola<T> siguiente;

        NodoCola(T dato) {
            this.dato = dato;
            this.siguiente = null;
        }
    }

    // Constructor
    public Cola() {
        frente = null;
        fin = null;
        tamaño = 0;
    }

    // Insertar un elemento al final de la cola (encolar)
    public void insertar(E elemento) {
        NodoCola<E> nuevo = new NodoCola<>(elemento);

        if (estaVacia()) {
            frente = nuevo;
            fin = nuevo;
        } else {
            fin.siguiente = nuevo;
            fin = nuevo;
        }
        tamaño++;
    }

    // Extraer el elemento del frente de la cola (desencolar)
    public E extraer() throws Exception {
        if (estaVacia()) {
            throw new Exception("Cola vacía: no se puede extraer");
        }

        E dato = frente.dato;
        frente = frente.siguiente;

        if (frente == null) {
            fin = null;
        }

        tamaño--;
        return dato;
    }

    // Verificar si la cola está vacía
    public boolean estaVacia() {
        return frente == null;
    }

    // Obtener el tamaño de la cola
    public int getTamaño() {
        return tamaño;
    }

    // Ver el elemento del frente sin extraerlo
    public E verFrente() throws Exception {
        if (estaVacia()) {
            throw new Exception("Cola vacía: no hay elementos para ver");
        }
        return frente.dato;
    }

    // Limpiar toda la cola
    public void limpiar() {
        frente = null;
        fin = null;
        tamaño = 0;
    }

    // Representación en String de la cola
    @Override
    public String toString() {
        if (estaVacia()) {
            return "Cola vacía []";
        }

        StringBuilder sb = new StringBuilder("Cola: [");
        NodoCola<E> actual = frente;

        while (actual != null) {
            sb.append(actual.dato);
            if (actual.siguiente != null) {
                sb.append(" <- ");
            }
            actual = actual.siguiente;
        }

        sb.append("]");
        return sb.toString();
    }
}