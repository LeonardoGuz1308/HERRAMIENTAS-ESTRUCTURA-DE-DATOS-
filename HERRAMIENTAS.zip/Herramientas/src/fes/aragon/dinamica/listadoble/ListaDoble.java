package fes.aragon.dinamica.listadoble;

public class ListaDoble <E>{
    private Nodo <E> cabeza;
    private Nodo <E> cola;
    protected int longitud = 0;
    public ListaDoble(){
        this.cabeza = null;
        this.cola = null;
        longitud = 0;
    }
    public void agregarEnCabeza(E dato){
        Nodo tmp = new Nodo <E>(dato,null,null);
        if (cola == null){
            cola = cabeza = tmp;
        }
        else{
            tmp.setSiguiente(cabeza);
            cabeza.setAnterior(tmp);
            cabeza = tmp;
        }
    }
    public void agregarEnCola(E dato){
        Nodo <E> tmp = new Nodo <E> (dato,null,null);
        if (cabeza == null){
            System.out.println("La lista esta vacia");
            cabeza = cola = tmp;
        }
        else{
            cola.setSiguiente(tmp);
            tmp.setAnterior(cola);
            cola = tmp;
        }
    }
}
