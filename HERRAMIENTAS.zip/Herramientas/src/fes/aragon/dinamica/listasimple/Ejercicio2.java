package fes.aragon.dinamica.listasimple;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.BufferedWriter;
import java.io.FileWriter;

public class Ejercicio2 {
    public static void main(String[] args) {

        // 1. Crear lista para almacenar números en el rango 30-150
        ListaSimple<Integer> listaFiltrada = new ListaSimple<>();

        // 2. Leer el archivo y filtrar números
        System.out.println("=== LEYENDO ARCHIVO ===");
        leerArchivo("LISTA_SIMPLE.txt", listaFiltrada);

        System.out.println("Total de números en el rango 30-150: " + listaFiltrada.getLongitud());

        // 3. Contar frecuencias (cuántas veces aparece cada número)
        System.out.println("\n=== CONTANDO FRECUENCIAS ===");
        int[] frecuencias = contarFrecuencias(listaFiltrada);

        // 4. Generar reporte en consola
        System.out.println("\n=== REPORTE DE FRECUENCIAS ===");
        mostrarReporte(frecuencias);

        // 5. Guardar reporte en archivo
        guardarReporte(frecuencias, "reporte_frecuencias.txt");

        System.out.println("\n✓ Proceso completado!");
    }

    /**
     * Lee el archivo y filtra números entre 30 y 150
     */
    public static void leerArchivo(String nombreArchivo, ListaSimple<Integer> lista) {
        try (BufferedReader reader = new BufferedReader(new FileReader(nombreArchivo))) {

            String linea;
            int lineaNumero = 1;

            while ((linea = reader.readLine()) != null) {
                System.out.println("Procesando línea " + lineaNumero + "...");

                // Dividir la línea por comas
                String[] numeros = linea.split(",");

                // Procesar cada número
                for (String numeroStr : numeros) {
                    try {
                        int numero = Integer.parseInt(numeroStr.trim());

                        // Filtrar: solo agregar si está entre 30 y 150
                        if (numero >= 30 && numero <= 150) {
                            lista.agregarEnCola(numero);
                        }
                    } catch (NumberFormatException e) {
                        System.err.println("Error al convertir: " + numeroStr);
                    }
                }

                lineaNumero++;
            }

            System.out.println("✓ Archivo leído correctamente");

        } catch (IOException e) {
            System.err.println("Error al leer el archivo: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Cuenta cuántas veces aparece cada número del 30 al 150
     * Retorna un arreglo donde el índice representa el número
     */
    public static int[] contarFrecuencias(ListaSimple<Integer> lista) {
        // Arreglo para contar (índice 30 = número 30, índice 150 = número 150)
        int[] frecuencias = new int[151]; // 0 a 150

        // Recorrer la lista y contar
        for (int i = 0; i < lista.getLongitud(); i++) {
            Integer numero = lista.getIndice(i);
            if (numero != null && numero >= 30 && numero <= 150) {
                frecuencias[numero]++;
            }
        }

        return frecuencias;
    }

    /**
     * Muestra el reporte en consola
     */
    public static void mostrarReporte(int[] frecuencias) {
        int totalEncontrados = 0;

        System.out.println("Número | Veces que apareció");
        System.out.println("-------|-------------------");

        for (int i = 30; i <= 150; i++) {
            if (frecuencias[i] > 0) {
                System.out.printf("%3d    | %d veces\n", i, frecuencias[i]);
                totalEncontrados++;
            }
        }

        System.out.println("\nNúmeros diferentes encontrados: " + totalEncontrados);
    }

    /**
     * Guarda el reporte en un archivo de texto
     */
    public static void guardarReporte(int[] frecuencias, String nombreArchivo) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(nombreArchivo))) {

            writer.write("=== REPORTE DE FRECUENCIAS ===\n");
            writer.write("Rango: 30 - 150\n");
            writer.write("================================\n\n");
            writer.write("Número | Veces que apareció\n");
            writer.write("-------|-------------------\n");

            int totalEncontrados = 0;
            int sumaFrecuencias = 0;

            for (int i = 30; i <= 150; i++) {
                if (frecuencias[i] > 0) {
                    writer.write(String.format("%3d    | %d veces\n", i, frecuencias[i]));
                    totalEncontrados++;
                    sumaFrecuencias += frecuencias[i];
                }
            }

            writer.write("\n================================\n");
            writer.write("Números diferentes encontrados: " + totalEncontrados + "\n");
            writer.write("Total de apariciones: " + sumaFrecuencias + "\n");

            System.out.println("\n✓ Reporte guardado en: " + nombreArchivo);

        } catch (IOException e) {
            System.err.println("Error al guardar el reporte: " + e.getMessage());
            e.printStackTrace();
        }
    }
}