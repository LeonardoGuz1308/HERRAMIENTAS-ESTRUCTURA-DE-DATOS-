package fes.aragon.dinamica.listasimple;

public class ListaSimple <E> {
    protected Nodo<E> cabeza;
    protected Nodo <E> cola;
    protected int longitud;
    public ListaSimple() {
        this.cabeza = null;
        this.cola = null;
        this.longitud = 0;
    }
    public void agregarEnCabeza(E dato) {
        cabeza = new Nodo <E> (dato,cabeza);
    if (cola == null) {
        cola = cabeza;
    }
    longitud++;
    }
    public void agregarEnCola(E dato) {
        if (cabeza == null) {
            cabeza = cola = new Nodo <E> (dato);
        } else {
            cola.setSiguiente(new Nodo<>(dato));
            cola = cola.getSiguiente();
        }
        longitud++;

    }
    public void imprimirElementos(){
        for (Nodo <E> tmp = cabeza; tmp != null; tmp = tmp.getSiguiente()) {
            System.out.println(tmp.getDato());
        }
    }
    public E obtenerCabeza() {
        return cabeza.getDato();
    }
    public E obtenerCola() {
        return cola.getDato();
    }
    public E getIndice(int indice){
        Nodo <E> tmp = cabeza;
       if (indice >= 0 && indice < longitud){
           for (int i = 0; i < indice; i++) {
                tmp = tmp.getSiguiente();
           }
           return tmp.getDato();
       }
       else{
           System.out.println("El indice no existe");
           return null;
       }

    }
    public void setIndice (E dato, int indice) {
        Nodo <E> tmp = cabeza;
        if (indice >= 0 && indice < longitud){
            for (int i = 0; i < indice; i++) {
                tmp = tmp.getSiguiente();
            }
            tmp.setDato(dato);
        }
        else{
            System.out.println("El indice no existe");
        }
    }
    public boolean eliminar(E dato) {
        boolean borrado = false;

        if (cabeza != null) {
            if (cabeza == cola && dato.equals(cabeza.getDato())) {
                cabeza = cola = null;
                borrado = true;
                longitud--;
            } else if (dato.equals(cabeza.getDato())) {
                cabeza = cabeza.getSiguiente();
                borrado = true;
                longitud--;
            } else {
                Nodo<E> prd = cabeza;
                Nodo<E> temp = cabeza.getSiguiente();

                while (temp != null && !temp.getDato().equals(dato)) {
                    prd = temp;
                    temp = temp.getSiguiente();
                }

                if (temp != null) {
                    prd.setSiguiente(temp.getSiguiente());
                    if (temp == cola) {
                        cola = prd;
                    }
                    borrado = true;
                    longitud--;
                }
            }
        }
        return borrado;
    }
    public int getLongitud(){
        return this.longitud;
    }

}
