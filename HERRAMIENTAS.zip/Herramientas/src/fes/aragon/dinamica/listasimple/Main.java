package fes.aragon.dinamica.listasimple;
import java.math.*;
import java.util.Random;
import java.io.FileWriter;
import java.io.IOException;
import java.io.BufferedWriter;
public class Main {
    public static void main(String[] args) {
        ListaSimple<Integer> lista = new ListaSimple<>();
        Random rand = new Random();

        for (int i = 0; i < 10000; i++) {
            int NumeroAleatorio = rand.nextInt(300) + 1;
            lista.agregarEnCola(NumeroAleatorio);
        }
        System.out.println("Longitud de la lista es " + lista.getLongitud());
        lista.imprimirElementos();

        guardarEnArchivo(lista,"LISTA_SIMPLE.txt");
    }

    public static void guardarEnArchivo(ListaSimple<Integer> lista, String archivo) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(archivo))) {

            System.out.println("Guardando en archivo: " + archivo);

            int contador = 0;
            StringBuilder linea = new StringBuilder();

            // Recorrer toda la lista
            for (int i = 0; i < lista.getLongitud(); i++) {
                Integer numero = lista.getIndice(i);

                // Agregar el número a la línea
                linea.append(numero);
                contador++;

                // Verificar si llegamos a 1000 o es el último elemento
                if (contador % 1000 == 0 || i == lista.getLongitud() - 1) {
                    // Escribir la línea completa
                    writer.write(linea.toString());
                    writer.newLine();

                    int numerosFila = (contador % 1000 == 0) ? 1000 : (contador % 1000);
                    System.out.println("Fila " + (contador / 1000 + (contador % 1000 > 0 ? 1 : 0)) +
                            " guardada (" + numerosFila + " números)");

                    // Reiniciar la línea para la siguiente fila
                    linea = new StringBuilder();
                } else {
                    // Si no es el último de la fila, agregar coma
                    linea.append(",");
                }
            }

            System.out.println("\n✓ Archivo guardado exitosamente!");
            System.out.println("Total de números guardados: " + contador);

        } catch (IOException e) {
            System.err.println("✗ Error al guardar el archivo: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
